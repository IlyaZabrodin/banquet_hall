CREATE TABLE `orderreport` (
  `idrep` int NOT NULL AUTO_INCREMENT,
  `idmanag` int NOT NULL,
  `r_year` int NOT NULL,
  `r_month` int NOT NULL,
  `ord_amount` int NOT NULL,
  `ord_sum` int NOT NULL,
  PRIMARY KEY (`idrep`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

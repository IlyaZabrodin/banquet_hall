CREATE TABLE `menu` (
  `iddish` int NOT NULL AUTO_INCREMENT,
  `dish_name` varchar(45) NOT NULL,
  `dish_price` int NOT NULL,
  `dish_weight` int NOT NULL,
  PRIMARY KEY (`iddish`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

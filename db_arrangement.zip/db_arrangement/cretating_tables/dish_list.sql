CREATE TABLE `dish_list` (
  `iddish_list` int NOT NULL AUTO_INCREMENT,
  `iddish` int NOT NULL,
  `idorder` int NOT NULL,
  `dish_amount` int DEFAULT NULL,
  PRIMARY KEY (`iddish_list`),
  KEY `idish_idx` (`iddish`),
  KEY `idorder_idx` (`idorder`),
  CONSTRAINT `iddish` FOREIGN KEY (`iddish`) REFERENCES `menu` (`iddish`),
  CONSTRAINT `idorder` FOREIGN KEY (`idorder`) REFERENCES `client_order` (`idorder`)
) ENGINE=InnoDB AUTO_INCREMENT=112 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `salereport` (
  `idrep` int NOT NULL AUTO_INCREMENT,
  `idhall` int NOT NULL,
  `r_year` int NOT NULL,
  `r_month` int NOT NULL,
  `reserves_number` int NOT NULL,
  `real_cost` int NOT NULL,
  PRIMARY KEY (`idrep`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

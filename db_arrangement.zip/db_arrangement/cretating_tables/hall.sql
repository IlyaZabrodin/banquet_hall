CREATE TABLE `hall` (
  `idhall` int NOT NULL AUTO_INCREMENT,
  `hall_name` varchar(15) NOT NULL,
  `max_place_amount` int NOT NULL,
  PRIMARY KEY (`idhall`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

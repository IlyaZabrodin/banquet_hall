CREATE TABLE `client_order` (
  `idorder` int NOT NULL AUTO_INCREMENT,
  `idmanager` int DEFAULT NULL,
  `banquet_time` datetime NOT NULL,
  `expected_place_amount` int NOT NULL,
  `idhall` int NOT NULL,
  `prepaid_expense` int DEFAULT NULL,
  `dish_amount` int DEFAULT NULL,
  `real_cost` int DEFAULT NULL,
  `order_status` varchar(45) DEFAULT NULL,
  `client_phone` varchar(45) DEFAULT NULL,
  `user_id` int DEFAULT NULL,
  PRIMARY KEY (`idorder`),
  KEY `idmanager_idx` (`idmanager`),
  KEY `idhall_idx` (`idhall`),
  CONSTRAINT `idhall` FOREIGN KEY (`idhall`) REFERENCES `hall` (`idhall`),
  CONSTRAINT `idmanager` FOREIGN KEY (`idmanager`) REFERENCES `manager` (`idmanager`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

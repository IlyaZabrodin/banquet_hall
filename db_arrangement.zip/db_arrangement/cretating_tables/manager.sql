CREATE TABLE `manager` (
  `idmanager` int NOT NULL AUTO_INCREMENT,
  `passport_data` varchar(45) NOT NULL,
  `birth_date` date NOT NULL,
  `employment_date` date NOT NULL,
  `layoff_date` date DEFAULT NULL,
  PRIMARY KEY (`idmanager`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
